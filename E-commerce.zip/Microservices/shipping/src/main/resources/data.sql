INSERT INTO SHIPPING(orderid,total,name,phone, address, status) VALUES
(123,999.99,'vaidees','01234','Chennai','Order Received');
