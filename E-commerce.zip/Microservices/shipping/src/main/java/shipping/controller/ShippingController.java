package shipping.controller;

import java.util.List;

import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import shipping.model.Shipping;
import shipping.service.ShippingService;

@Api(value = "OrdersController", description = "REST Apis related to Products Entity!!!!")
@RestController
public class ShippingController {

	private Logger logger = LoggerFactory.getLogger(ShippingController.class.getName());

	@Autowired
	ShippingService service;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private Queue queue;

	@ApiOperation(value = "Insert shipping details and send to shipping consumer ", response = Shipping.class, tags = "createshipment")
	@RequestMapping(value = "/shipping", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> createShipment(@RequestBody Shipping shipping) {

		Shipping shippingInfo = service.CreateShipment(shipping);
		logger.info("Shipping Controller - Inserted shipping Info");

		String OrderDetails = "Name:" + shippingInfo.getName() + "\nPhone:" + shippingInfo.getPhone() + "\nOrderID:"
				+ shippingInfo.getOrderID() + "\nshippingid:" + shippingInfo.getId() + "\nTotal:"
				+ shippingInfo.getTotal();
		logger.info("Shipping Controller - Order Details -" + OrderDetails);

		jmsTemplate.convertAndSend(queue, OrderDetails);
		logger.info("Shipping Controller - Order details sent to shipping consumer");

		return new ResponseEntity<String>(OrderDetails, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get shipping info based on OrderID/ShippingID/All ", response = Shipping.class, tags = "getmatchedshipping")
	@RequestMapping(value = "/shipping", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<List<Shipping>> getProductsByDescription(
			@RequestParam(value = "orderid", required = false) Long orderID,
			@RequestParam(value = "shippingid", required = false) Long id) {

		if (orderID != null && id == null) {
			List<Shipping> model = service.getShippingByOrderID(orderID);
			logger.info("Shipping Controller - getShippingByOrderID");
			return new ResponseEntity<List<Shipping>>(model, new HttpHeaders(), HttpStatus.OK);

		} else if (orderID == null && id != null) {
			List<Shipping> model = service.getShippingByShippingID(id);
			logger.info("Shipping Controller - getShippingByShippingID");
			return new ResponseEntity<List<Shipping>>(model, new HttpHeaders(), HttpStatus.OK);
		} else {
			List<Shipping> model = service.getAllShipping();
			logger.info("Shipping Controller - getAllShipping");
			return new ResponseEntity<List<Shipping>>(model, new HttpHeaders(), HttpStatus.OK);
		}

	}

	@ApiOperation(value = "Patch shipping details ", response = Shipping.class, tags = "patchShippingDetails")
	@RequestMapping(value = "/shipping/{shippingID}", method = RequestMethod.PATCH)
	public @ResponseBody ResponseEntity<Shipping> patchShippingDetails(@RequestBody Shipping shipping,
			@PathVariable("shippingID") Long id) {
		Shipping model = service.patchShippingDetails(shipping, id);
		logger.info("Shipping Controller - patchShippingDetails");
		return new ResponseEntity<Shipping>(model, new HttpHeaders(), HttpStatus.OK);
	}

}
