package shipping.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "shipping")
@Component
public class Shipping {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "orderid", nullable = false)
	private long orderID;

	@Column(name = "total", nullable = false)
	private BigDecimal total;

	@Column(name = "name")
	private String name;

	@Column(name = "phone")
	private String phone;

	@Column(name = "address")
	private String address;

	@Column(name = "status")
	private String status;

	public Shipping() {

	}

	public Shipping(long orderid, BigDecimal total, String name, String phone, String address, String status) {
		this.orderID=orderid;
		this.total=total;
		this.name=name;
		this.phone=phone;
		this.address=address;
		this.status=status;
	}
	
	public Shipping(long id,long orderid, BigDecimal total, String name, String phone, String address, String status) {
		this.id=id;
		this.orderID=orderid;
		this.total=total;
		this.name=name;
		this.phone=phone;
		this.address=address;
		this.status=status;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getOrderID() {
		return orderID;
	}

	public void setOrderID(long orderID) {
		this.orderID = orderID;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
