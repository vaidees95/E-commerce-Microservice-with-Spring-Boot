package shipping.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import shipping.model.Shipping;
import shipping.repository.ShippingRepository;

@Service
public class ShippingService {

	@Autowired
	ShippingRepository repository;

	public Shipping CreateShipment(Shipping shipping) {

		return repository.save(shipping);

	}

	public List<Shipping> getAllShipping() {
		List<Shipping> productsList = repository.findAll();
		if (productsList.size() > 0) {
			return productsList;
		} else {
			return new ArrayList<Shipping>();
		}
	}
	
	public List<Shipping> getShippingByOrderID(Long orderID) {

		List<Shipping> productDescription = repository.findByOrderID(orderID);
		if (productDescription.size() > 0) {
			return productDescription;
		} else {
			return new ArrayList<Shipping>();
		}
		
	}
	
	
	
	public List<Shipping> getShippingByShippingID(Long id) {

		List<Shipping> productCategory = repository.findByid(id);
		if (productCategory.size() > 0) {
			return productCategory;
		} else {
			return new ArrayList<Shipping>();
		}
	}
	
	public Shipping patchShippingDetails(Shipping newShipping, long id) {

		Shipping shipping = repository.findById(id).get();
		shipping.setStatus(newShipping.getStatus());
		return repository.save(shipping);
	}
	
}
