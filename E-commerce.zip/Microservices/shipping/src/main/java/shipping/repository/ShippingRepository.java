package shipping.repository;

import org.springframework.stereotype.Repository;

import shipping.model.Shipping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ShippingRepository extends JpaRepository<Shipping, Long> {

	List<Shipping> findByOrderID(Long orderid);

	List<Shipping> findByid(Long id);
	

}