package com.edureka.shipping;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ShippingIntegrationTest.class)
public class ShippingIntegrationTest {
	
	
	@Test	
	@Order(1)
	public void checkStatus() 
	{
		
		TestRestTemplate restTemplate = new TestRestTemplate();		
		ResponseEntity<String> response =  restTemplate.getForEntity("http://localhost:8080/shipping/shipping", String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
				
	}
	
	
	
	

	
}
