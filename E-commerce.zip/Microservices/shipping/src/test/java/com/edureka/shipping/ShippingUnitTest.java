package com.edureka.shipping;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import shipping.model.Shipping;
import shipping.repository.ShippingRepository;
import shipping.service.ShippingService;

@SpringBootTest(classes = ShippingUnitTest.class)
public class ShippingUnitTest {
	
	@Mock
	ShippingRepository repository;

	@InjectMocks
	ShippingService shippingService;

	@Test
	@Order(1)
	public void getAllShipping() {
		List<Shipping> shipping = new ArrayList<Shipping>();
		shipping.add(new Shipping(123L,new BigDecimal(999.99),"vaidees","01234","Chennai", "Order Received"));
		when(repository.findAll()).thenReturn(shipping);
		assertThat(shippingService.getAllShipping().size()).isEqualTo(1);
	}
	
	@Test
	@Order(2)
	public void getShippingByOrderID() {
		
		Shipping shippingTemp =new Shipping(123L,new BigDecimal(999.99),"vaidees","01234","Chennai", "Order Received");
		List<Shipping> shipping = new ArrayList<Shipping>();
		shipping.add(new Shipping(123L,new BigDecimal(999.99),"vaidees","01234","Chennai", "Order Received"));
		
		Long orderID = 123L;
		when(repository.findByOrderID(orderID)).thenReturn(List.of(shipping.get(0)));
		assertThat(shippingService.getShippingByOrderID(orderID).size()).isEqualTo(1);
		assertThat(shippingService.getShippingByOrderID(orderID).get(0).getName()).isEqualTo(shippingTemp.getName());
	
	}
	
	@Test
	@Order(3)
	public void getShippingByShippingID() {
		
		Shipping shippingTemp =new Shipping(1,123L,new BigDecimal(999.99),"vaidees","01234","Chennai", "Order Received");
		List<Shipping> shipping = new ArrayList<Shipping>();
		shipping.add(new Shipping(1,123L,new BigDecimal(999.99),"vaidees","01234","Chennai", "Order Received"));
		
		long shippingID = 1L;
		when(repository.findByid(shippingID)).thenReturn(List.of(shipping.get(0)));
		assertThat(shippingService.getShippingByShippingID(shippingID).size()).isEqualTo(1);
		assertThat(shippingService.getShippingByShippingID(shippingID).get(0).getName()).isEqualTo(shippingTemp.getName());
	
	}

}