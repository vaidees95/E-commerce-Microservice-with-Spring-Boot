package com.edureka.products;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.edureka.products.model.Products;
import com.edureka.products.repository.ProductsRepository;
import com.edureka.products.service.ProductsService;



@SpringBootTest(classes = ProductsUnitTest.class)
public class ProductsUnitTest {

	@Mock
	ProductsRepository repository;

	@InjectMocks
	ProductsService productService;

	@Test
	@Order(1)
	public void getAllProducts() {
		List<Products> product = new ArrayList<Products>();
		product.add(new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2));
		product.add(new Products(2L,101L, "iPhone13", "phone watch", new BigDecimal(999.99),3));
		product.add(new Products(3L,102L, "Apple Watch Series 7", "Watch", new BigDecimal(499.99),4));

		when(repository.findAll()).thenReturn(product);
		assertThat(productService.getAllProducts().size()).isEqualTo(3);
	}
	
	@Test
	@Order(2)
	public void getProductsByProductID() {
		
		Products productsTemp =new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2);
		
		List<Products> product = new ArrayList<Products>();
		product.add(new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2));
		product.add(new Products(2L,101L, "iPhone13", "phone watch", new BigDecimal(999.99),3));
		product.add(new Products(3L,102L, "Apple Watch Series 7", "Watch", new BigDecimal(499.99),4));
		
		Long productID = 100L;
		when(repository.findByProductID(productID)).thenReturn(Optional.of(product.get(0)));
		assertThat(productService.getProductsByProductID(productID).getCategory()).isEqualTo(productsTemp.getCategory());
	
	}
	
	@Test
	@Order(3)
	public void getProductsByDescription() {
		
		Products productsTemp =new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2);
		List<Products> product = new ArrayList<Products>();
		product.add(new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2));
		
		String productDesc = "iPhone13";
		when(repository.findByDescription(productDesc)).thenReturn(List.of(product.get(0)));
		assertThat(productService.getProductsByDescription(productDesc).size()).isEqualTo(1);
		assertThat(productService.getProductsByDescription(productDesc).get(0).getProductID()).isEqualTo(productsTemp.getProductID());
	
	}
	
	@Test
	@Order(4)
	public void getProductsByCatetory() {
		
		Products productsTemp =new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2);
		List<Products> product = new ArrayList<Products>();
		product.add(new Products(1L,100L, "iPhone13", "phone", new BigDecimal(999.99),2));
		
		String productCategory = "phone";
		when(repository.findByCategory(productCategory)).thenReturn(List.of(product.get(0)));
		assertThat(productService.getProductsByCatetory(productCategory).size()).isEqualTo(1);
		assertThat(productService.getProductsByCatetory(productCategory).get(0).getProductID()).isEqualTo(productsTemp.getProductID());
	
	}

}