package com.edureka.products.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.edureka.products.model.Products;
import com.edureka.products.service.ProductsService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "ProductsController", description = "REST Apis related to Products Entity!!!!")
@RestController
public class ProductsController {

	RestTemplate restTemplate;

	private Logger logger = LoggerFactory.getLogger(ProductsController.class);
	@Autowired
	ProductsService service;

	@ApiOperation(value = "Get products on ProductID ", response = Products.class, tags = "getproductsbyproductid")
	@RequestMapping(value = "/products/{productID}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<Products> getProductsByProductID(@PathVariable("productID") Long productID) {
		Products model = service.getProductsByProductID(productID);
		logger.info("Products Controller - getProductsByProductID");
		return new ResponseEntity<Products>(model, new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get product based on Description/Category/All ", response = Products.class, tags = "getmatchedproducts")
	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<List<Products>> getMatchedProducts(
			@RequestParam(value = "description", required = false) String description,
			@RequestParam(value = "category", required = false) String category) {
		if (description != null && category == null) {
			List<Products> model = service.getProductsByDescription(description);
			logger.info("Products Controller - getProductsByDescription");
			return new ResponseEntity<List<Products>>(model, new HttpHeaders(), HttpStatus.OK);
		} else if (description == null && category != null) {
			List<Products> model = service.getProductsByCatetory(category);
			logger.info("Products Controller - getProductsByCatetory");
			return new ResponseEntity<List<Products>>(model, new HttpHeaders(), HttpStatus.OK);
		} else {
			List<Products> model = service.getAllProducts();
			logger.info("Products Controller - getAllProducts");
			return new ResponseEntity<List<Products>>(model, new HttpHeaders(), HttpStatus.OK);
		}
	}
	
	@ApiOperation(value = "Insert product details ", response = Products.class, tags = "createProductsDetails")
	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Products> createProductsDetails(@RequestBody Products products) {
		Products model = service.createProductsDetails(products);
		logger.info("Products Controller - updateProductsDetails");
		return new ResponseEntity<Products>(model, new HttpHeaders(), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Update product details ", response = Products.class, tags = "updateproductsdetails")
	@RequestMapping(value = "/products/{productID}", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity<Products> updateProductsDetails(@RequestBody Products products,
			@PathVariable("productID") Long productID) {
		Products model = service.updateProductsDetails(products, productID);
		logger.info("Products Controller - updateProductsDetails");
		return new ResponseEntity<Products>(model, new HttpHeaders(), HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Patch product details ", response = Products.class, tags = "patchProductDetails")
	@RequestMapping(value = "/products/{productID}/{quantity}", method = RequestMethod.PATCH)
	public @ResponseBody ResponseEntity<String> patchProductDetails(@PathVariable("productID") Long productID,
			@PathVariable("quantity") int quantity) {
		Products model = service.patchProductDetails(quantity, productID);
		logger.info("Shipping Controller - patchProductDetails");
		return new ResponseEntity<String>("Patched", new HttpHeaders(), HttpStatus.OK);
	}
	
	@ApiOperation(value = "Delete product details ", response = Products.class, tags = "deleteProductDetails")
	@RequestMapping(value = "/products/{id}", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity<String> deleteProductDetails(@PathVariable("id") long id) {
		service.deleteProductDetails(id);
		logger.info("Shipping Controller - deleteProductDetails");
		return new ResponseEntity<String>("Successfully deleted", new HttpHeaders(), HttpStatus.OK);
	}

	public ProductsController(@Lazy RestTemplate restTemplate) {
		super();
		this.restTemplate = restTemplate;
	}

	@LoadBalanced
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
