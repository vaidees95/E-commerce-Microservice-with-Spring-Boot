package com.edureka.products.repository;

import org.springframework.stereotype.Repository;
import com.edureka.products.model.Products;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface ProductsRepository
	extends JpaRepository<Products, Long> {
	
	
	Optional<Products> findByProductID(Long productID);
	List<Products> findByDescription(String description);
	List<Products> findByCategory(String category);
	 
}