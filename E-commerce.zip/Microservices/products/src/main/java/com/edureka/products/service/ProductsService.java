package com.edureka.products.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.edureka.products.model.Products;
import com.edureka.products.repository.ProductsRepository;
@Transactional
@Service
public class ProductsService {

	@Autowired
	ProductsRepository repository;

	public List<Products> getAllProducts() {
		List<Products> productsList = repository.findAll();
		if (productsList.size() > 0) {
			return productsList;
		} else {
			return new ArrayList<Products>();
		}
	}

	public Products getProductsByProductID(Long productID) {

		Optional<Products> product = repository.findByProductID(productID);
		return product.get();
	}

	public List<Products> getProductsByDescription(String description) {

		List<Products> productDescription = repository.findByDescription(description);
		if (productDescription.size() > 0) {
			return productDescription;
		} else {
			return new ArrayList<Products>();
		}

	}

	public List<Products> getProductsByCatetory(String category) {

		List<Products> productCategory = repository.findByCategory(category);
		if (productCategory.size() > 0) {
			return productCategory;
		} else {
			return new ArrayList<Products>();
		}
	}

	public Products createProductsDetails(Products product) {

		return repository.save(product);

	}
	
	
	public Products updateProductsDetails(Products newProduct, long productID) {

		return repository.findByProductID(productID)
			      .map(product -> {
			    	  product.setDescription(newProduct.getDescription());
			    	  product.setCategory(newProduct.getCategory());
			    	  product.setPrice(newProduct.getPrice());
			    	  product.setQuantity(newProduct.getQuantity());
			        return repository.save(product);
			      })
			      .orElseGet(() -> {
			        return repository.save(newProduct);
			      });

	}
	
	public Products patchProductDetails(int quantity, long productID) {

		Products products = repository.findByProductID(productID).get();
		products.setQuantity(quantity);
		return repository.save(products);
	}
	
	public void deleteProductDetails(long id) {

		repository.deleteById(id);
	}
	

}
