INSERT INTO PRODUCTS (productid, description, category, price, quantity) VALUES
(100,'iPhone13','phone','999.99',2),
(101,'iPhone13','phone watch','999.99',3),
(102,'Apple Watch Series 7','Watch','499.99',4);

