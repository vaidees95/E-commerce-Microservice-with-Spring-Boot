package orders.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.jms.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import ch.qos.logback.classic.Level;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import orders.model.OrderShip;
import orders.model.Orders;
import orders.model.Products;
import orders.model.Shipping;
import orders.service.OrdersService;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "OrdersController", description = "REST Apis related to Products Entity!!!!")
@RestController
public class OrdersController {

	private static final Logger logger = LoggerFactory.getLogger(OrdersController.class.getName());

	@Autowired
	OrdersService service;

	RestTemplate restTemplate;

	public boolean CheckStock(List<Orders> orders) {
		List<Products> productsList = new ArrayList<Products>();
		logger.info("Orders Controller - Check availability and update stock");
		for (Orders order : orders) {

			Products products = restTemplate
					.getForObject("http://127.0.0.1:8080/products/products/" + order.getProductID(), Products.class);

			if (products.getQuantity() < order.getQuantity()) {
				return false;
			} else {
				products.setOrderQuantity(order.getQuantity());
				productsList.add(products);
			}

		}

		for (Products product : productsList) {

			String URL = "http://127.0.0.1:8080/products/products/" + product.getProductID() + "/"
					+ (product.getQuantity() - product.getOrderQuantity());

			logger.info(URL);

			RestTemplate restTemplate = new RestTemplate();
			HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
			restTemplate.setRequestFactory(httpRequestFactory);
			restTemplate.patchForObject(URL, null, String.class);

		}
		return true;
	}

	@ApiOperation(value = "Insert order details and call shipping and products service", response = Orders.class, tags = "createordersandcallshippingandproductsservice")
	@RequestMapping(value = "/orders", method = RequestMethod.POST)
	@HystrixCommand(fallbackMethod = "CallShippingandProductsServiceAndGetData_Fallback")

	public @ResponseBody ResponseEntity<String> CreateOrdersandCallShippingandProducts(
			@RequestBody OrderShip orderShip) throws IOException {

		if (CheckStock(orderShip.getOrders())) {

			long orderID = new Random().nextInt(100);
			BigDecimal total = service.CreateOrders(orderShip.getOrders(), orderID);
			logger.info("Orders Controller - Inserted order details");

			orderShip.getShipping().setOrderID(orderID);
			orderShip.getShipping().setTotal(total);

			HttpHeaders headers = new HttpHeaders();
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<Shipping> entity = new HttpEntity<Shipping>(orderShip.getShipping(), headers);

			logger.info("Orders Controller - Shipping details sending to shipping service");
			String response = restTemplate
					.exchange("http://localhost:8080/shipping/shipping", HttpMethod.POST, entity, String.class)
					.getBody();

			logger.info("Orders Controller - Response from shipping service:" + response);

			return new ResponseEntity<String>(response, new HttpHeaders(), HttpStatus.OK);
			
		} else {
			return new ResponseEntity<String>("Out of stock", new HttpHeaders(), HttpStatus.OK);
		}
	}

	@ApiIgnore
	@ApiOperation(value = "Fallback shippping and products service ", response = Shipping.class, tags = "createordersandcallshippingservice_fallback")
	private ResponseEntity<String> CallShippingandProductsServiceAndGetData_Fallback(@RequestBody OrderShip orderShip) {

		System.out.println("Shipping/Products Service is down!!! fallback route enabled...");
		logger.info("Orders Controller - Shipping/Products Service is down!!! fallback route enabled...");
		return new ResponseEntity<String>(
				"CIRCUIT BREAKER ENABLED!!! No Response From Shipping/Products Service at this moment. "
						+ " Service will be back shortly - " + new Date(),
				new HttpHeaders(), HttpStatus.OK);
	}

	@ApiOperation(value = "Get all orders", response = Shipping.class, tags = "getallorders")
	@RequestMapping(value = "/orders", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<List<Orders>> getAllOrders() {

		List<Orders> model = service.getAllOrders();
		logger.info("Orders Controller - getAllOrders");
		return new ResponseEntity<List<Orders>>(model, new HttpHeaders(), HttpStatus.OK);

	}

	public OrdersController(@Lazy RestTemplate restTemplate) {
		super();
		this.restTemplate = restTemplate;
	}

	@LoadBalanced
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
