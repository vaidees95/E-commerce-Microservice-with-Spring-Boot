package orders.model;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class OrderShip {

	
	List<Orders> orders;
	Shipping shipping;
	
	public OrderShip(){
		
	}
	public List<Orders> getOrders() {
		return orders;
	}
	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}
	public Shipping getShipping() {
		return shipping;
	}
	public void setShipping(Shipping shipping) {
		this.shipping = shipping;
	}
}
