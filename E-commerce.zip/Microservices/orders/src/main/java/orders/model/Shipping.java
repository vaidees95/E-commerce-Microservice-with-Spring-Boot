package orders.model;

import java.math.BigDecimal;

import javax.persistence.Column;

import org.springframework.stereotype.Component;
@Component
public class Shipping {


	private long orderID;	
	private BigDecimal total;
	private String name;
	private String phone;
	private String address;
	private String status;
	
	public Shipping() {
		status="Order Received";
	}
	
	public long getOrderID() {
		return orderID;
	}
	public void setOrderID(long orderID) {
		this.orderID = orderID;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
