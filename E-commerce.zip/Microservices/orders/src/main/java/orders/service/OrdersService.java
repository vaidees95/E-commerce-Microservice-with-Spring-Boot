package orders.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.jms.Queue;

import org.apache.activemq.util.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import orders.model.Orders;
import orders.model.Shipping;
import orders.repository.OrdersRepository;

@Service
public class OrdersService {

	@Autowired
	OrdersRepository repository;

	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private Queue queue;

	BigDecimal total = new BigDecimal(0);

	public BigDecimal CreateOrders(List<Orders> orders, long orderID) throws IOException {

		total = new BigDecimal(0);
		
		for (Orders order : orders) {

			Map<String, String> map = new HashMap<String, String>();
			map.put("category", order.getCategory());
			map.put("description", order.getDescription());
			jmsTemplate.convertAndSend(queue, map);

			total = (order.getPrice().multiply(new BigDecimal(order.getQuantity()))).add(total);
			order.setOrderID(orderID);
			repository.save(order);

		}
		return total;

	}

	public List<Orders> getAllOrders() {
		List<Orders> ordersList = repository.findAll();
		if (ordersList.size() > 0) {
			return ordersList;
		} else {
			return new ArrayList<Orders>();
		}
	}
}
