package orders.repository;

import org.springframework.stereotype.Repository;

import orders.model.Orders;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface OrdersRepository
	extends JpaRepository<Orders, Long> {
	
	 
}