INSERT INTO ORDERS(orderid,productid, description, category, price,quantity) VALUES
(123,107,'iPhone13','phone','999.99',1);
