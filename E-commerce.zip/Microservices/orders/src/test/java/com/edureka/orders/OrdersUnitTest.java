package com.edureka.orders;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;

import orders.model.Orders;
import orders.repository.OrdersRepository;
import orders.service.OrdersService;

@SpringBootTest(classes = OrdersUnitTest.class)
public class OrdersUnitTest {
	
	@Mock
	OrdersRepository repository;

	@InjectMocks
	OrdersService service;

	@Test
	@Order(1)
	public void getAllProducts() {
		List<Orders> product = new ArrayList<Orders>();
		product.add(new Orders(123L, 107L,"iPhone13", "phone", new BigDecimal(999.99)));

		when(repository.findAll()).thenReturn(product);
		assertEquals(1, service.getAllOrders().size());
	}
	

}