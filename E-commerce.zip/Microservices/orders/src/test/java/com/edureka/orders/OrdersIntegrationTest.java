package com.edureka.orders;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = OrdersIntegrationTest.class)
public class OrdersIntegrationTest {
	
	
	@Test	
	@Order(1)
	public void getProductsByProductID() 
	{
		
		TestRestTemplate restTemplate = new TestRestTemplate();		
		ResponseEntity<String> response =  restTemplate.getForEntity("http://localhost:8080/orders/orders", String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
				
	}
	
	
	
	

	
}
