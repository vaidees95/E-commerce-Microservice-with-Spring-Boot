package com.edureka.productsrecommendation.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.edureka.productsrecommendation.model.ProductsRecommendationModel;
import com.edureka.productsrecommendation.service.ProductsRecommendationService;

import io.swagger.annotations.ApiOperation;



@RestController
public class ProductsRecommendationController {
	
	private final Logger logger = LoggerFactory.getLogger(ProductsRecommendationController.class);
	
	@Autowired
	ProductsRecommendationService service;
	
	@ApiOperation(value = "Get all products for recommendation", response = ProductsRecommendationModel.class, tags = "getallproductsforrecommendation")
	@RequestMapping(value = "/productsrecommendation", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<List<ProductsRecommendationModel>> getallproductsforrecommendation() {
		
		List<ProductsRecommendationModel> model = service.getAllProductsRecommendation();
		logger.info("Orders Controller - getAllProductsRecommendation");
		return new ResponseEntity<List<ProductsRecommendationModel>>(model, new HttpHeaders(), HttpStatus.OK);
	

	}
	


}
