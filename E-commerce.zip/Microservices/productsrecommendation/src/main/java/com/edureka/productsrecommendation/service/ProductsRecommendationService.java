package com.edureka.productsrecommendation.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edureka.productsrecommendation.model.ProductsRecommendationModel;
import com.edureka.productsrecommendation.repository.ProductsRecommendationRepository;


@Service
public class ProductsRecommendationService {

	@Autowired
	ProductsRecommendationModel productsRecommendationModel;

	@Autowired
	ProductsRecommendationRepository repository;

	private final Logger logger = LoggerFactory.getLogger(ProductsRecommendationModel.class);

	public void CreateProductsRecommendation(Map<String, String> arr_combined) {
		for (Map.Entry<String, String> entry : arr_combined.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			logger.info(key + ":" + value);
			if (key.equals("category")) {
				productsRecommendationModel.setCategory(value);
			}
			if (key.equals("description")) {
				productsRecommendationModel.setDescription(value);
			}
		}
		repository.save(productsRecommendationModel);

	}
	
	public List<ProductsRecommendationModel> getAllProductsRecommendation() {
		List<ProductsRecommendationModel> productsList = repository.findAll();
		if (productsList.size() > 0) {
			return productsList;
		} else {
			return new ArrayList<ProductsRecommendationModel>();
		}
	}
}
