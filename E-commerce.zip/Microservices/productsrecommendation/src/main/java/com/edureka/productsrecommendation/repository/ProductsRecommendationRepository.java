package com.edureka.productsrecommendation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edureka.productsrecommendation.model.ProductsRecommendationModel;

@Repository
public interface ProductsRecommendationRepository extends JpaRepository<ProductsRecommendationModel, Long> {

}
