package com.edureka.productsrecommendation.consumer;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.edureka.productsrecommendation.service.ProductsRecommendationService;



@Component
@EnableJms
public class ProductsRecommendationConsumer {
	
	@Autowired
	ProductsRecommendationService service;

    private final Logger logger = LoggerFactory.getLogger(ProductsRecommendationConsumer.class);

   
    
    @JmsListener(destination = "productsrecommendation-queue")
    public void listener(Map<String, String> arr_combined){
    	service.CreateProductsRecommendation(arr_combined);
    	
    	}
      
    	
    }

