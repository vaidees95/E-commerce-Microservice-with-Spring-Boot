DROP TABLE IF EXISTS productsrecommendation;
  
CREATE TABLE productsrecommendation(
  id INT AUTO_INCREMENT  PRIMARY KEY,
  description VARCHAR(250) NOT NULL,
  category VARCHAR(250) NOT NULL
);


