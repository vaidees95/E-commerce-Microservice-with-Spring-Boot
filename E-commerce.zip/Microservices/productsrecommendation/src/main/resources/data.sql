INSERT INTO productsrecommendation(description,category) VALUES
('iPhone13','phone');
