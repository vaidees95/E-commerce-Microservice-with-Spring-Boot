package com.edureka.productsrecommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsrecommendationApplicationTests {

	
	void contextLoads() {
	}

}
