package com.edureka.productsrecommendation;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.edureka.productsrecommendation.model.ProductsRecommendationModel;
import com.edureka.productsrecommendation.repository.ProductsRecommendationRepository;
import com.edureka.productsrecommendation.service.ProductsRecommendationService;



@SpringBootTest(classes = ProductsRecommendationUnitTest.class)
public class ProductsRecommendationUnitTest {

	@Mock
	ProductsRecommendationRepository repository;

	@InjectMocks
	ProductsRecommendationService productService;

	@Test
	@Order(1)
	public void getAllProducts() {
		
		ProductsRecommendationModel productsTemp =new ProductsRecommendationModel("iPhone13", "phone");
		
		List<ProductsRecommendationModel> product = new ArrayList<ProductsRecommendationModel>();
		product.add(new ProductsRecommendationModel("iPhone13", "phone"));
		product.add(new ProductsRecommendationModel("Apple Watch Series 7", "Watch"));

		when(repository.findAll()).thenReturn(product);
		assertThat(	productService.getAllProductsRecommendation().size()).isEqualTo(2);
		assertThat(productService.getAllProductsRecommendation().get(0).getCategory()).isEqualTo(productsTemp.getCategory());
	}
	
	

}