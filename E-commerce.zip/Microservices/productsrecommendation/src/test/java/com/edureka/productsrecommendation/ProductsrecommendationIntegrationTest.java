package com.edureka.productsrecommendation;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ProductsrecommendationIntegrationTest.class)
public class ProductsrecommendationIntegrationTest {
	
	
	@Test	
	@Order(1)
	public void CheckStatus() 
	{
		
		TestRestTemplate restTemplate = new TestRestTemplate();		
		ResponseEntity<String> response =  restTemplate.getForEntity("http://localhost:8080/productsrecommendation/productsrecommendation", String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
				
	}
	
	
	
	

	
}
