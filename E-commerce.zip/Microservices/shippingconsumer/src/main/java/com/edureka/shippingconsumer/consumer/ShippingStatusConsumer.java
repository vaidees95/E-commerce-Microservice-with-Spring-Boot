package com.edureka.shippingconsumer.consumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
@EnableJms
public class ShippingStatusConsumer {
	 private final Logger logger = LoggerFactory.getLogger(ShippingStatusConsumer.class);

	    @JmsListener(destination = "Shipping-status")
	    public void listener(String message){
	    	logger.info("Shipping Consumer - deliver notification to customer:"+message);
	        
	    }
}
