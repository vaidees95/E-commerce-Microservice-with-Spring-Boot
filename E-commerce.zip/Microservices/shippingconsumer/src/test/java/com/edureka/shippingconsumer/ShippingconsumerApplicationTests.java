package com.edureka.shippingconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
